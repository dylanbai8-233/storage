<!-- 底部 -->
 	<div class = "footer">
		<div class = "layui-container">
			<div class = "layui-row">
				<div class = "layui-col-lg12">
				Copyright © 2017-2018 Powered by <a href="https://github.com/helloxz/zdir" target = "_blank">Zdir</a> | Author <a href="https://www.xiaoz.me/" target = "_blank">xiaoz.me</a>
				</div>
			</div>
		</div>
	</div>
	<!-- 底部END -->
	
	<!--遍历目录END-->
	<script type="text/javascript" src = "https://libs.xiaoz.top/jquery/2.0.3/jquery-2.0.3.min.js"></script>
	<script type="text/javascript" src="./static/layui/layui.js"></script>
	<script type="text/javascript" src="./static/embed.js?v=1.10"></script>
	<script type="text/javascript" src="https://libs.xiaoz.top/clipBoard.js/clipBoard.min.js"></script>
</body>
</html>