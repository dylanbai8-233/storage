<?php

//解析接口（单线）
$github1 = 'http://yude268.coding.me/fuckvip/api/vipjx.txt';

//绑定域名
$domain = 'http://url.adboys.cn';

?>