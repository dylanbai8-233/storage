<?php
require_once 'config.inc.php';
header("location:$domain")
?>