<?php
include_once './header.inc.php';
?>

      <div class="jumbotron">
        <h1>接口链接</h1>

		<form action="./adddone.php" method="post">

        <p class="lead">
            <input class="form-control" type="text" name="name" onclick="select()" value="" placeholder="请输入完整接口链接，包含：http:// 或 https://" >
        </p>
        <p><button class="btn btn-lg btn-primary" type="submit" >立即收藏</button></p>

        </form>

      </div>

<?php
include_once '../footer.inc.php';
?>
