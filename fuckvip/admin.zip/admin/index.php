<?php
include_once './header.inc.php';
?>

      <div class="jumbotron">
        <h1>接口链接</h1>

		<form action="./bookmarklet.php" method="post">

        <p class="lead">
            <input class="form-control" type="text" name="name" onclick="select()" value="http://url.adboys.cn/short.php?url=" >
        </p>
        <p><button class="btn btn-lg btn-primary" type="submit" >立即生成</button></p>

        </form>

      </div>

<?php
include_once '../footer.inc.php';
?>
