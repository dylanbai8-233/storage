<?php
include_once './header.inc.php';
?>

        <div class="jumbotron">
            <h1>操作完成</h1>

                <?php if (strstr($_POST["name"],"http")){
				$myfile = fopen("./apilist.txt", "a") or die ("写入文件失败，请检查权限！");
				$txt = "[".date("Y-m-d")."]:\n".$_POST["name"]."\n\n";
				fwrite($myfile, $txt);
				fclose($myfile);?>

				<p><a href="http://<?php echo $_SERVER['SERVER_NAME']; ?>/admin/apilist.txt" target="_blank">查看收藏目录</a></p>
                <p><a class="btn btn-success" href="./addapi.php">返回前页</a></p>
                <?php }else{ ?>

                <div class="alert alert-danger" role="alert">请输入正确的接口链接，链接须包含"http://"或"https://"。</div>
                <p><a class="btn btn-success" href="./addapi.php">返回前页</a></p>
                <?php } ?>

        </div>

<?php
include_once '../footer.inc.php';
?>
