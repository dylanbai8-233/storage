<?php
include_once './header.inc.php';
?>

        <div class="jumbotron">
            <h1>拖拽链接</h1>

                <?php if (strstr($_POST["name"],"http")){ ?>
                <p class="lead ">
				<h3>[ <a href="javascript:window.location = '<?php echo $_POST["name"]; ?>'+window.location.href" >VIP视频破解</a> ]</h3>
				</p>
				<p>拖拽上方蓝色字到收藏夹或者右键复制链接自行收藏</p>
                <p><a class="btn btn-success" href="./">返回前页</a></p>
                <?php }else{ ?>

                <div class="alert alert-danger" role="alert">请输入正确的接口链接，链接须包含"http://"或"https://"。</div>
                <p><a class="btn btn-success" href="./">返回前页</a></p>
                <?php } ?>

        </div>

<?php
include_once '../footer.inc.php';
?>
