<div class="footer">
    <p>网站功能：破解全网视频网站，免费观看VIP视频，跳过视频广告，生成短链接。</p>
    <p>支持网站：<a href="https://vip.iqiyi.com/" target="_blank">爱奇艺VIP</a> <a href="https://film.qq.com/" target="_blank">腾讯视频VIP</a> <a href="https://vip.youku.com/" target="_blank">优酷VIP</a> <a href="https://film.sohu.com/" target="_blank">搜狐视频VIP</a> <a href="https://www.mgtv.com/vip/" target="_blank">芒果视频VIP</a> <a href="http://vip.le.com/" target="_blank">乐视VIP</a> <a href="http://vip.yinyuetai.com/" target="_blank">音乐台VIP</a> <a href="https://www.bilibili.com/" target="_blank">B站</a></p>
    <p>Copyright © <a href="http://<?php echo $_SERVER['SERVER_NAME']; ?>" target="_blank"><?php echo $_SERVER['SERVER_NAME']; ?></a> 版权所有</p>
</div>

</div>

<script src="js/ie10-viewport-bug-workaround.js"></script>

<script LANGUAGE="javascript">

    function urlcheck()
    {
        if(document.sina.url.value.length==0){
            alert("请输入链接");
            document.sina.url.focus();
            return false;
        }

        else{
            return true;
        }

    }

</script>

</body>
</html>