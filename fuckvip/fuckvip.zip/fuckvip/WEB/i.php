<?php
require_once 'config.inc.php';
$vip_mor = file_get_contents($github2);
$url = $_GET['url'];
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="renderer" content="webkit">
    <meta name="referrer" content="never">
    <meta http-equiv="Cache-Control" content="no-transform"> 
    <meta http-equiv="Cache-Control" content="no-siteapp">
    <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <meta name="viewport" content="width=520, initial-scale=1, maximum-scale=1, user-scalable=yes">
    <title>全网VIP视频破解_http://<?php echo $_SERVER['SERVER_NAME']; ?>_免广告！免会员！畅享VIP！</title>
    <link rel="stylesheet" type="text/css" href="/css/i.css">
    <link rel="shortcut icon" href="/favicon.ico"/>
    <link rel="bookmark" href="/favicon.ico"/>
</head>

<body>
    <div id="main">
        <div class="header clearfix">
            <h2><a href="<?php echo $api_more; ?>">—— 多线路VIP视频解析破解 ——</a></h2>
        </div>
            <div id="menu">
            <ul id="playpanel" class="list tip clearfix">
                <select id="api"></select>
                <input id="url" type="text" value="<? echo $url ?>" placeholder="输入完整视频网址，包含：http://">
                <button id="play" onclick="play();">点击播放</button>
            </ul>         
            </div>

        <ul id="player" class="list table">
            <div class="body">
			<br>
			<p><h2>[ <a href="javascript:window.location = '<?php echo $api_more; ?>'+window.location.href" >多线路VIP视频破解</a> ]</h2></p>
			使用方法（电脑）：<br><br>
			[一键破解全网VIP视频，免会员，免广告！]<br><br>
			1.拖动上方红字 “多线路VIP视频破解” 到浏览器收藏夹保存（IE或Edge右键复制链接后自行添加收藏）；<br><br>
			2.打开任意视频播放页（如：爱奇艺 腾讯视频 优酷 搜狐视频等）；<br><br>
			3.点击收藏夹链接 “多线路VIP视频破解” 自动跳转到本页后 “点击播放”。<br><br>
			支持网站：<a href="https://vip.iqiyi.com/" target="_blank">爱奇艺VIP</a> <a href="https://film.qq.com/" target="_blank">腾讯视频VIP</a> <a href="https://vip.youku.com/" target="_blank">优酷VIP</a> <a href="https://film.sohu.com/" target="_blank">搜狐视频VIP</a> <a href="https://www.mgtv.com/vip/" target="_blank">芒果视频VIP</a> <a href="http://vip.le.com/" target="_blank">乐视VIP</a> <a href="http://vip.yinyuetai.com/" target="_blank">音乐台VIP</a> <a href="https://www.bilibili.com/" target="_blank">B站</a>
            </div>
        </ul>
        <div id="foot">
            <div class="header footer">
            </div>            
        </div>
    </div>

    <script>
        var data = [
<?php echo $vip_mor; ?>
                ];
        for (var i in  data){
            var opt = document.createElement ("option");
            opt.value = data[i].url;
            opt.innerText = data[i].name;
            document.getElementById("api").appendChild (opt);
        }
        function play(){
            var url = document.getElementById("url").value;
            if(url.indexOf('http') == -1){  
                alert('视频地址不正确！');return;
            }
            var api = document.getElementById("api").value;
            url = api + url;
            document.getElementById("player").innerHTML='<iframe marginwidth="0" marginheight="0" hspace="0" vspace="0" frameborder="0" allowfullscreen="true" scrolling="no" height="100%" width="100%" src="'+url+'"></iframe>';
        }
    </script>

</body>
</html>
