<?php
require_once 'config.inc.php';
$vip_api = file_get_contents($github1);
$url = $vip_api.$_GET['url'];
?>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport"/>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=11" />
  <title>全网VIP视频破解_http://<?php echo $_SERVER['SERVER_NAME']; ?>_免广告！免会员！畅享VIP！</title>
  <link href="/css/style.css" rel="stylesheet">
</head>

<body>
<div class="player">

<iframe id="player" width="100%" height="100%" allowfullscreen="true"  scrolling="no" frameborder="0"  border="0" marginwidth="0" marginheight="0" src="<? echo $url ?>" ></iframe>

</div>
</body>

</html>
