<?php

//解析接口（单线）
$github1 = 'http://yude268.coding.me/fuckvip/api/vipjx.txt';

//解析接口（多线）
$github2 = 'http://yude268.coding.me/fuckvip/api/vipmor.txt';

//绑定域名
$domain = 'http://'.$_SERVER['SERVER_NAME'];


$api_url = $domain.'/api.php?url=';
$api_short = $domain.'/short.php?url=';
$api_more = $domain.'/i.php?url=';

?>