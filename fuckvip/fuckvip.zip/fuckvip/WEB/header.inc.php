<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="css/jumbotron-narrow.css" rel="stylesheet">
    <script src="js/ie-emulation-modes-warning.js"></script>
    <title>全网VIP视频破解_http://<?php echo $_SERVER['SERVER_NAME']; ?>_免广告！免会员！畅享VIP！</title>
    <script type="text/javascript" language="javascript">
       function select(){
       	  alert("1")
       }
    </script>
</head>

<body>

<div class="container">
    <div class="header">
        <ul class="nav nav-pills pull-right" role="tablist">
            <li role="presentation"><a href="/share.php">一键短链</a></li>
            <li role="presentation"><a href="/onekey.php">一键破解</a></li>
        </ul>
        <h3 class="text-muted"><a href="/">畅享VIP</a></h3>
    </div>