<?php
include_once 'header.inc.php';
require_once 'config.inc.php';
?>

    <div class="jumbotron">
        <h2><a href="javascript:window.location = '<?php echo $api_short; ?>'+window.location.href" >一键破解并生成短链</a></h2>

            <p class="lead" align="left">
			使用方法(电脑)：<br>
			[一键破解VIP视频并生成永久短链接，方便微信等分享]<br>
			1.拖动上方蓝字“一键破解并生成短链”到浏览器收藏夹保存；<br>
			IE或Edge右键复制链接后自行添加收藏<br>
			2.打开任意视频播放页(爱奇艺 腾讯视频 优酷 搜狐视频等)；<br>
			3.点击收藏夹链接 “一键破解并生成短链” 即可破解。<br>
            </p>
    </div>

<?php
include_once 'footer.inc.php';
?>