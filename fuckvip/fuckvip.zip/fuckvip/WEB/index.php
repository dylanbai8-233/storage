<?php
include_once 'header.inc.php';
?>

      <div class="jumbotron">
        <h1>视频链接</h1>
        <form name="sina" method="get" action="/short.php" onsubmit="return urlcheck()" >
        <p class="lead">
            <input name="url" class="form-control" type="text" onclick="select()" value="https://www.iqiyi.com/v_19rra0h3wg.html [示例]" >
        </p>
        <p><button class="btn btn-lg btn-primary" type="submit" >立即破解</button></p>
        </form>
      </div>

<?php
include_once 'footer.inc.php';
?>