<?php
//设置密码 判断提交密码 正确/错误/空
$password = "0";//在此设置密码
$p = "";if(isset($_COOKIE["isview"]) and $_COOKIE["isview"] == $password){
$isview = true;}else{
if(isset($_POST["pwd"])){
if($_POST["pwd"] == $password){
setcookie("isview",$_POST["pwd"],time()+3600*3);$isview = true;}else{$p = (empty($_POST["pwd"])) ? "输入密码继续操作！" : "<div style=\"color:#F00;\">密码不正确！</div>";}
}else{$isview = false;$p = "输入密码继续操作。";}}?>
<?php if($isview){


//判断密码正确时 进入下面横线内网页
?>
<!-- ----------------1---------------- -->

<?php
//从地址栏获取要加入收藏的网址
$url = $_GET['url'];
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>私人收藏夹</title>
<link rel="shortcut icon" href="/favicon.ico"/>
<link rel="bookmark" href="/favicon.ico"/>
</head>
<body>

<table cellspacing="0" cellpadding="0">
<tr>
<td style="WORD-BREAK: break-all; WORD-WRAP: break-word">
<div style="margin-left: 1em; margin-right: 1em">

<div>
<h3><a style="color:#292929;text-decoration:none"; href="./" >私人收藏夹</a></h3>
<form action="./" method="post">

<p><input type="text" name="fenlei" onclick="select()" value="默认分类" ></p>
<p><input type="text" name="name" onclick="select()" value="书签描述" ></p>
<p><input type="text" name="url" onclick="select()" value="<? echo $url ?>" placeholder="必须包含 http(s)://" </p>

<p><button type="submit" >立即收藏</button></p>

</form>
</div>

</div>
</td>
</tr>
</table>

</body>
</html>

<!-- -----------------2--------------- -->


<?php }else{
//判断密码为错/空首次访问时 进入下面横线内网页
?>
<!-- -----------------1--------------- -->

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>私人收藏夹</title>
<link rel="shortcut icon" href="/favicon.ico"/>
<link rel="bookmark" href="/favicon.ico"/>
</head>
<body>

<table cellspacing="0" cellpadding="0">
<tr>
<td style="WORD-BREAK: break-all; WORD-WRAP: break-word">
<div style="margin-left: 1em; margin-right: 1em">

<form action="" method="post">
<h3><a style="color:#292929;text-decoration:none"; href="./" >请输入密码</a></h3>
<p><input type="password" name="pwd" /></p>
<p><input type="submit" value="确定" /></p>
</form>
<p><?php echo $p;?></p>

</div>
</td>
</tr>
</table>

</body>
</html>

<!-- -----------------2--------------- -->
<?php }?>
