<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>私人收藏夹</title>
</head>
<body>

<table cellspacing="0" cellpadding="0">
<tr>
<td style="WORD-BREAK: break-all; WORD-WRAP: break-word">
<div style="margin-left: 1em; margin-right: 1em">

<h3><a style="color:#292929;text-decoration:none"; href="./">私人收藏夹</a></h3>

<?php
//检查提交链接格式是否正确 写入数据库txt 日期/分类/描述/链接
if (strstr($_POST["url"],"http")){
$myfile = fopen("./note.txt", "a") or die ("写入文件失败，请检查权限！");
$txt = "\n\n\n<a style=\"color:#B5B5B5\">".date("Y-m-d")."</a><br>\n[".$_POST["fenlei"]."]-".$_POST["name"]."<br>\n<a style=\"color:#B5B5B5;text-decoration:none\"; target=_black; href=".$_POST["url"]." >".$_POST["url"]."</a><br><br>";
fwrite($myfile, $txt);
fclose($myfile);
header("Location: {$_SERVER['REQUEST_URI']}");//防止刷新 重复提交

}else{ ?>
<p>点击进入：<a style="color:#008B8B;text-decoration:none"; href="./mark.php">手动收藏</a>&nbsp;&nbsp;&nbsp;拖拽小书签：<a style="color:#008B8B;text-decoration:none"; href="javascript:window.location = '<?php echo "http://".$_SERVER['SERVER_NAME']."/test/mark.php?url="; ?>'+window.location.href" >一键收藏</a></p>
<?php } ?>

<?php
//从数据库txt 读取数据 倒序展示
$str = file_get_contents('note.txt');
$max = substr_count($str,']-');
$group = $max + "1";
$array = explode("\n\n",$str);
echo "<p>关键词检索：Ctrl+f &nbsp; 当前收藏文章总数：".$max."</p> \n\n";

echo "<p>";
for($i=1;$i<$group;$i++){
    echo $array[$group-$i];}
echo "\n</p>\n";
?>

<p>使用方法：(电脑)拖拽小书签到收藏栏保存或者右键复制链接手动收藏。</p>
<p>收藏方法：浏览网页时，点击收藏栏“一键收藏”按提示输入书签描述。</p>

</div>
</td>
</tr>
</table>

</body>
</html>