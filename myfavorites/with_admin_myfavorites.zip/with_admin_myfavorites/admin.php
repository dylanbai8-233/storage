<?php
//设置密码 判断提交密码 正确/错误/空
$password = "0";//在此设置密码
$p = "";if(isset($_COOKIE["isview"]) and $_COOKIE["isview"] == $password){
$isview = true;}else{
if(isset($_POST["pwd"])){
if($_POST["pwd"] == $password){
setcookie("isview",$_POST["pwd"],time()+3600*3);$isview = true;}else{$p = (empty($_POST["pwd"])) ? "输入密码继续操作！" : "<div style=\"color:#F00;\">密码不正确！</div>";}
}else{$isview = false;$p = "输入密码继续操作。";}}?>
<?php if($isview){


//判断密码正确时 进入下面横线内网页
?>
<!-- ----------------1---------------- -->

<?php
//从地址栏获取要加入收藏的网址
$url = $_GET['url'];
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>管理收藏夹</title>
<link rel="shortcut icon" href="/favicon.ico"/>
<link rel="bookmark" href="/favicon.ico"/>
</head>
<body>

<table cellspacing="0" cellpadding="0">
<tr>
<td style="WORD-BREAK: break-all; WORD-WRAP: break-word">
<div style="margin-left: 1em; margin-right: 1em">

<div>
<h3><a style="color:#292929;text-decoration:none"; href="./" >管理收藏夹</a></h3>
<form action="" method="post">

<p><input type="text" name="line" onclick="select()" placeholder="请输入 line 值" onkeyup="(this.v=function(){this.value=this.value.replace(/[^0-9-]+/,'');}).call(this)" onblur="this.v();" </p>

<p><button type="submit" >立即删除</button></p>

</form>
</div>

<?php
//判断line值是否为空
$del = $_POST["line"];
if($del==''){
echo "<p>请输入要删除的 line 值！</p>\r\n";
echo "<p>技巧：输入不存在的line值 直接备份数据库！</p>\r\n\r\n";
echo "</div>\r\n";
echo "</td>\r\n";
echo "</tr>\r\n";
echo "</table>\r\n\r\n";
echo "</body>\r\n";
echo "</html>\r\n";
exit;
}
?>

<?php
//备份数据库note.txt
$dir = iconv("UTF-8", "GBK", "./baktxt");
if (!file_exists($dir)){
mkdir ($dir,0777,true);
echo "<p>执行中 请稍后...</p>\r\n";
} else {
echo "<p>执行中 请稍后...</p>\r\n";
}
$bakname = date("YmdHis").".txt";
$source_name = "note.txt";
$copy_name = "note.bak";
$target_path = "./baktxt/";
$target_name = $target_path.$bakname;
copy($source_name,$copy_name);
rename($copy_name,$target_name);
echo "<p>提示：收藏夹已备份！</p>";
?>

<?php
//检测line值是否存在
$str = file_get_contents('note.txt');
$max = substr_count($str,'||');
if($del>$max || $del<1){
echo "<p>line 值不存在 取消删除操作！</p>\r\n";
//列出历史备份
$file = scandir($target_path);
echo "<p>历史备份列表：</p>\r\n";
echo "<pre>";
echo "----------------------------- ";
print_r($file);
echo "-------------------------------- End\r\n\r\n";
echo "</div>\r\n";
echo "</td>\r\n";
echo "</tr>\r\n";
echo "</table>\r\n\r\n";
echo "</body>\r\n";
echo "</html>\r\n";
exit;
}
//删除指定line相关数据
$filename = "note.txt";
$delline1 = ($del-1)*3+1;
$delline2 = ($del-1)*3+2;
$delline3 = ($del-1)*3+3;
$farray = file($filename);
for($i=0;$i<count($farray);$i++)
{
    if(strcmp($i+1,$delline1)==0)
    {
        continue;
    }
    if(strcmp($i+1,$delline2)==0)
    {
        continue;
    }
    if(strcmp($i+1,$delline3)==0)
    {
        continue;
    }
    if(trim($farray[$i])<>"")//清除空行
    {
        $newfp.=$farray[$i];
    }
}
$fp=@fopen($filename,"w");
@fputs($fp,$newfp);
@fclose($fp);
echo "<p>提示：删除已完成！</p>";
?>

<?php
//列出历史备份
$file = scandir($target_path);
echo "<p>历史备份列表：</p>\r\n";
echo "<pre>";
echo "----------------------- ";
print_r($file);
echo "------------------------- End\r\n\r\n";
?>
</div>
</td>
</tr>
</table>

</body>
</html>

<!-- -----------------2--------------- -->


<?php }else{
//判断密码为错/空首次访问时 进入下面横线内网页
?>
<!-- -----------------1--------------- -->

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>管理收藏夹</title>
<link rel="shortcut icon" href="/favicon.ico"/>
<link rel="bookmark" href="/favicon.ico"/>
</head>
<body>

<table cellspacing="0" cellpadding="0">
<tr>
<td style="WORD-BREAK: break-all; WORD-WRAP: break-word">
<div style="margin-left: 1em; margin-right: 1em">

<form action="" method="post">
<h3><a style="color:#292929;text-decoration:none"; href="./" >请输入密码</a></h3>
<p><input type="password" name="pwd" /></p>
<p><input type="submit" value="确定" /></p>
</form>
<p><?php echo $p;?></p>

</div>
</td>
</tr>
</table>

</body>
</html>

<!-- -----------------2--------------- -->
<?php }?>
